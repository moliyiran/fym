<?php
// 应用公共文件
error_reporting(E_ALL ^ E_NOTICE);
