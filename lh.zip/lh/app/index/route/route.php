<?php
use think\facade\Route;
// 注册路由到News控制器的read操作
Route::rule('kaihistory.html','/index/kaihistory');
Route::rule('Hkheader.html','/public/kaihistory');